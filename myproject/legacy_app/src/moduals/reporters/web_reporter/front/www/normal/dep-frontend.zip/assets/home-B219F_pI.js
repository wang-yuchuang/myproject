import{a as o}from"./index-BVwn-asu.js";const s=e=>o.get("/api/home",{params:e}),a=e=>o.post("/api/home",e);export{s as h,a as s};
